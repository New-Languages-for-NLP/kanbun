Kanbun pipeline optimized for CPU. Components: tok2vec, tagger, parser, senter, lemmatizer.

| Feature | Description |
| --- | --- |
| **Name** | `lzh_kanbun_sm` |
| **Version** | `0.0.1` |
| **spaCy** | `>=3.2.1,<3.3.0` |
| **Default Pipeline** | `tok2vec`, `ner` |
| **Components** | `tok2vec`, `ner` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | `MIT` |
| **Author** | [New Languages for NLP](https://newnlp.princeton.edu) |

### Label Scheme

<details>

<summary>View label scheme (6 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`ner`** | `LOC`, `PERSON`, `PERSONderiv`, `WORK_OF_ART`, `WORK_OF_ARTderiv`, `null` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `ENTS_F` | 83.56 |
| `ENTS_P` | 79.77 |
| `ENTS_R` | 87.74 |
| `TAG_ACC` | 0.00 |
| `DEP_UAS` | 0.00 |
| `DEP_LAS` | 0.00 |
| `DEP_LAS_PER_TYPE` | 0.00 |
| `SENTS_P` | 0.00 |
| `SENTS_R` | 0.00 |
| `SENTS_F` | 0.00 |
| `TOK2VEC_LOSS` | 227848.43 |
| `NER_LOSS` | 317716.30 |